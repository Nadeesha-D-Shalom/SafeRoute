package com.example.saferoute;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaferouteApplicationTests {

	@Test
	void contextLoads() {
	}

}
